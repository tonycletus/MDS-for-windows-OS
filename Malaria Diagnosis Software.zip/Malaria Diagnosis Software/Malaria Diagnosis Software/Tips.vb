﻿Public Class Tips

    Private Sub Tips_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub RichTextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RichTextBox1.TextChanged

    End Sub

    Private Sub lblknow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblknow.Click

    End Sub
End Class